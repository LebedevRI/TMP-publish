var _float16_8h =
[
    [ "float16_t", "struct_halide_1_1float16__t.html", "struct_halide_1_1float16__t" ],
    [ "bfloat16_t", "struct_halide_1_1bfloat16__t.html", "struct_halide_1_1bfloat16__t" ],
    [ "halide_type_of< Halide::float16_t >", "_float16_8h.html#a60fb91856f0afd52187efc5813a3250c", null ],
    [ "halide_type_of< Halide::bfloat16_t >", "_float16_8h.html#ac05907f910af269bfb33c2e6821ceb8a", null ]
];