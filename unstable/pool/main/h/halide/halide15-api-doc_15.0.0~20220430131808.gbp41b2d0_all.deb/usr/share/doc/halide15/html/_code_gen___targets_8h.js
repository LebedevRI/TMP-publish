var _code_gen___targets_8h =
[
    [ "new_CodeGen_ARM", "_code_gen___targets_8h.html#af9591d2e435d4700e48c401d518028e0", null ],
    [ "new_CodeGen_Hexagon", "_code_gen___targets_8h.html#abc6f03a564d417dd1c679a350629edb0", null ],
    [ "new_CodeGen_MIPS", "_code_gen___targets_8h.html#a55b8661ce2ab3c7ba1c676a859f9b7b4", null ],
    [ "new_CodeGen_PowerPC", "_code_gen___targets_8h.html#a65b70e8bd4f4da5bbb2d75c15bc4c5b3", null ],
    [ "new_CodeGen_RISCV", "_code_gen___targets_8h.html#ae1e220b25bd0619a7fa65fb7a0c497b2", null ],
    [ "new_CodeGen_X86", "_code_gen___targets_8h.html#a6df19b0c3515a85a4c95c702e56ff459", null ],
    [ "new_CodeGen_WebAssembly", "_code_gen___targets_8h.html#a7bc02a28b00b1d499c747089faacaed0", null ]
];