var _func_8h =
[
    [ "VarOrRVar", "struct_halide_1_1_var_or_r_var.html", "struct_halide_1_1_var_or_r_var" ],
    [ "Stage", "class_halide_1_1_stage.html", "class_halide_1_1_stage" ],
    [ "FuncRef", "class_halide_1_1_func_ref.html", "class_halide_1_1_func_ref" ],
    [ "FuncTupleElementRef", "class_halide_1_1_func_tuple_element_ref.html", "class_halide_1_1_func_tuple_element_ref" ],
    [ "EvictionKey", "class_halide_1_1_eviction_key.html", "class_halide_1_1_eviction_key" ],
    [ "Func", "class_halide_1_1_func.html", "class_halide_1_1_func" ],
    [ "ScheduleHandle", "_func_8h.html#ad7b585cf844dcb14fa12386d743cbb24", null ],
    [ "min", "_func_8h.html#a842daf6fbd0f87ec9ea8336cb0cdd23e", null ],
    [ "max", "_func_8h.html#aea2c7f5fe6c79a49dcbb28951cf8405d", null ],
    [ "check_types", "_func_8h.html#a4b98bf6f8f3475caaa691d7884a31d45", null ],
    [ "check_types", "_func_8h.html#abec0560d55ceb7384483f00da38ad73f", null ],
    [ "assign_results", "_func_8h.html#a32bce2836846aa0286859b005b6aa015", null ],
    [ "assign_results", "_func_8h.html#acdc822256984ddc07c031b230ce2b8ae", null ],
    [ "evaluate", "_func_8h.html#aff8ebcd2c6d1995f4496d123a33626ad", null ],
    [ "evaluate", "_func_8h.html#a34f3541db2d08c4e3f18df546b8796ff", null ],
    [ "evaluate", "_func_8h.html#ab65c4f62c3040c34a00c31603404c58f", null ],
    [ "evaluate", "_func_8h.html#ab36a37228e934e5d99e0800ccc0a94a7", null ],
    [ "schedule_scalar", "_func_8h.html#a1f9bfb55aa0058e51d72037fde785fb0", null ],
    [ "evaluate_may_gpu", "_func_8h.html#a3ece4281929aec52e480d8021c43b020", null ],
    [ "evaluate_may_gpu", "_func_8h.html#a1d1ad1afdbe47ccd8e21b6576900e82e", null ]
];