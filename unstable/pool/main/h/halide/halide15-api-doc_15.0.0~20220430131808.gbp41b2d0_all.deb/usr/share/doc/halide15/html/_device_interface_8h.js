var _device_interface_8h =
[
    [ "get_device_interface_for_device_api", "_device_interface_8h.html#af7566eca1e318568c044f5b14d914842", null ],
    [ "get_default_device_api_for_target", "_device_interface_8h.html#a58a1df88c4f9bd924bd79a1120d14694", null ],
    [ "host_supports_target_device", "_device_interface_8h.html#a27245995e7e6ad0923dd764ad621b5aa", null ],
    [ "make_device_interface_call", "_device_interface_8h.html#adb129e599eb08042ff95446b7e040233", null ]
];