var _code_gen___p_t_x___dev_8h =
[
    [ "new_CodeGen_PTX_Dev", "_code_gen___p_t_x___dev_8h.html#a1088b9db437ecb80a185a8250a6196a8", null ]
];