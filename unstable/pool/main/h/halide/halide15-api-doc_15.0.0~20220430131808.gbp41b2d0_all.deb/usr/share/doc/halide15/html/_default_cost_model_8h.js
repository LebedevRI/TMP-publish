var _default_cost_model_8h =
[
    [ "DefaultCostModel", "class_halide_1_1_default_cost_model.html", "class_halide_1_1_default_cost_model" ],
    [ "make_default_cost_model", "_default_cost_model_8h.html#a98ec21770ee3d7bac1f0c1a9d5fd0644", null ]
];