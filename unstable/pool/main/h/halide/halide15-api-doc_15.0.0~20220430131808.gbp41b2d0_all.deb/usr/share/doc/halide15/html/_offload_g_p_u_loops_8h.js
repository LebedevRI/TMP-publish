var _offload_g_p_u_loops_8h =
[
    [ "inject_gpu_offload", "_offload_g_p_u_loops_8h.html#aad273923c5480df0e3753e3a70d240e6", null ]
];