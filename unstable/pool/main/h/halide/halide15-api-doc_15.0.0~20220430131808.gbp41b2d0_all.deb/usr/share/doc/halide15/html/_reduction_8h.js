var _reduction_8h =
[
    [ "ReductionVariable", "struct_halide_1_1_internal_1_1_reduction_variable.html", "struct_halide_1_1_internal_1_1_reduction_variable" ],
    [ "Compare", "struct_halide_1_1_internal_1_1_reduction_variable_1_1_compare.html", "struct_halide_1_1_internal_1_1_reduction_variable_1_1_compare" ],
    [ "ReductionDomain", "class_halide_1_1_internal_1_1_reduction_domain.html", "class_halide_1_1_internal_1_1_reduction_domain" ],
    [ "Compare", "struct_halide_1_1_internal_1_1_reduction_domain_1_1_compare.html", "struct_halide_1_1_internal_1_1_reduction_domain_1_1_compare" ],
    [ "split_predicate_test", "_reduction_8h.html#aedcc74570e61290111488ef861e03d0f", null ]
];