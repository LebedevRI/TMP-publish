var _region_costs_8h =
[
    [ "Cost", "struct_halide_1_1_internal_1_1_cost.html", "struct_halide_1_1_internal_1_1_cost" ],
    [ "RegionCosts", "struct_halide_1_1_internal_1_1_region_costs.html", "struct_halide_1_1_internal_1_1_region_costs" ],
    [ "is_func_trivial_to_inline", "_region_costs_8h.html#a6b8bfb7d84886e922f43c911740f2b1e", null ]
];