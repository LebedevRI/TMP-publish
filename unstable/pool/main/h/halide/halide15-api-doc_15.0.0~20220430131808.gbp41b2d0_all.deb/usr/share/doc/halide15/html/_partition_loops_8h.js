var _partition_loops_8h =
[
    [ "has_uncaptured_likely_tag", "_partition_loops_8h.html#aa4498b50bbce3ab2d9915233d648be38", null ],
    [ "has_likely_tag", "_partition_loops_8h.html#a40fd7d8d9eafda07ee9a314c3c869f2d", null ],
    [ "partition_loops", "_partition_loops_8h.html#a3d00fe3db9030d30827191d78c36fda5", null ]
];