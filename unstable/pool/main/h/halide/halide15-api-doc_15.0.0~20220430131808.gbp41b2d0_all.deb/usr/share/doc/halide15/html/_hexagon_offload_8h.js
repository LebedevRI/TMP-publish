var _hexagon_offload_8h =
[
    [ "inject_hexagon_rpc", "_hexagon_offload_8h.html#a8696c48228f0cb335255ae46954909e1", null ],
    [ "compile_module_to_hexagon_shared_object", "_hexagon_offload_8h.html#a55a0c1dd9c3f33e07eb6df7b59850286", null ]
];