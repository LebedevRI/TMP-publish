var _target_8h =
[
    [ "Target", "struct_halide_1_1_target.html", "struct_halide_1_1_target" ],
    [ "get_host_target", "_target_8h.html#a0ae94266acfeba1bce3298e333ba4b8c", null ],
    [ "get_target_from_environment", "_target_8h.html#ab25236e75d4d73bee045028da680215d", null ],
    [ "get_jit_target_from_environment", "_target_8h.html#a9d2cf046902155db63e83374f23a47b5", null ],
    [ "target_feature_for_device_api", "_target_8h.html#a8ab19de8fa28eb2396a0b8d40c338491", null ],
    [ "target_test", "_target_8h.html#ae0ca85eaf8baf3957bda33b83b20c694", null ]
];