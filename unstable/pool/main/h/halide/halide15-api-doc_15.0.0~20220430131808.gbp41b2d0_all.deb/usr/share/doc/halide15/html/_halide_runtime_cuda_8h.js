var _halide_runtime_cuda_8h =
[
    [ "HALIDE_RUNTIME_CUDA", "_halide_runtime_cuda_8h.html#a2870a985f9fca93d2be1d3a3d2d3e1ea", null ],
    [ "halide_cuda_acquire_context_t", "_halide_runtime_cuda_8h.html#ab2adf366a9428d9402ad2a5e2aed49f4", null ],
    [ "halide_cuda_release_context_t", "_halide_runtime_cuda_8h.html#ab2455368e5747f840cbb279a32c7c704", null ],
    [ "halide_cuda_get_stream_t", "_halide_runtime_cuda_8h.html#a3bb0d64f1f1432f06299d10b97c13f20", null ],
    [ "halide_cuda_device_interface", "_halide_runtime_cuda_8h.html#a5f05898deab5c495a5dda1bcd676abc6", null ],
    [ "halide_cuda_initialize_kernels", "_halide_runtime_cuda_8h.html#a73669b08f4d2ae469d9315a9455cf920", null ],
    [ "halide_cuda_run", "_halide_runtime_cuda_8h.html#a533d3dbf983acb36df1a1d7c18ba2dad", null ],
    [ "halide_cuda_finalize_kernels", "_halide_runtime_cuda_8h.html#a84e61551ad1af9691fce571b6a368dfb", null ],
    [ "halide_cuda_wrap_device_ptr", "_halide_runtime_cuda_8h.html#a41e4a6067f2d0604c7f381482055a5c5", null ],
    [ "halide_cuda_detach_device_ptr", "_halide_runtime_cuda_8h.html#ad51a1a79ca9ad94c895cb5afeb6a8cc5", null ],
    [ "halide_cuda_get_device_ptr", "_halide_runtime_cuda_8h.html#a374269b7f4f223df9bad62492beead9e", null ],
    [ "halide_cuda_release_unused_device_allocations", "_halide_runtime_cuda_8h.html#a60b96f8b8bb0d93fa8e8107bf35ed76a", null ],
    [ "halide_set_cuda_acquire_context", "_halide_runtime_cuda_8h.html#a9119f3e9d0467d3787da1e49181cb392", null ],
    [ "halide_set_cuda_release_context", "_halide_runtime_cuda_8h.html#abfb1af80302ec971aaaa07f631183d85", null ],
    [ "halide_set_cuda_get_stream", "_halide_runtime_cuda_8h.html#ae2255bc37e898b65fe0d9fdccc7b3ab7", null ]
];