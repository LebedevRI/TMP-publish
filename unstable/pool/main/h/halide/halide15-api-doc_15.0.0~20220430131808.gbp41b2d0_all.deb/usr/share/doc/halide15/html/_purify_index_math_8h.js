var _purify_index_math_8h =
[
    [ "purify_index_math", "_purify_index_math_8h.html#a875f0768e69428144a610e591c7d9796", null ]
];