var _network_size_8h =
[
    [ "head1_channels", "_network_size_8h.html#aab7e8f5756fe34d428d6c70095cdcf8b", null ],
    [ "head1_w", "_network_size_8h.html#aa373ab31181627dc3ed16ac676e561a8", null ],
    [ "head1_h", "_network_size_8h.html#aee8790329f3be3d6c675a7868c944311", null ],
    [ "head2_channels", "_network_size_8h.html#a93bf8c7312090d7f312590aec7192719", null ],
    [ "head2_w", "_network_size_8h.html#a1660f1a4cc56d0271d2942ce9437ec8c", null ],
    [ "conv1_channels", "_network_size_8h.html#abde902a9d2b5fae2afad7f7b7edb1c9c", null ]
];