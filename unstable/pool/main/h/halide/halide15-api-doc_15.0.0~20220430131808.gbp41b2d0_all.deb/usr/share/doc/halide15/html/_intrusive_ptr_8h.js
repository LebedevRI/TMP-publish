var _intrusive_ptr_8h =
[
    [ "RefCount", "class_halide_1_1_internal_1_1_ref_count.html", "class_halide_1_1_internal_1_1_ref_count" ],
    [ "IntrusivePtr", "struct_halide_1_1_internal_1_1_intrusive_ptr.html", "struct_halide_1_1_internal_1_1_intrusive_ptr" ],
    [ "ref_count", "_intrusive_ptr_8h.html#abbc100b5bea312321ff79baff93ee558", null ],
    [ "destroy", "_intrusive_ptr_8h.html#a11ca920b642ef490aeac2b4e864d6254", null ]
];