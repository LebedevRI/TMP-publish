var _prefetch_directive_8h =
[
    [ "PrefetchDirective", "struct_halide_1_1_internal_1_1_prefetch_directive.html", "struct_halide_1_1_internal_1_1_prefetch_directive" ],
    [ "PrefetchBoundStrategy", "_prefetch_directive_8h.html#a36b78b48c1fe9126344a218d07348f4d", [
      [ "Clamp", "_prefetch_directive_8h.html#a36b78b48c1fe9126344a218d07348f4da08825280e3f8137556325061ba67ff8c", null ],
      [ "GuardWithIf", "_prefetch_directive_8h.html#a36b78b48c1fe9126344a218d07348f4da5b80e0001d7f4873a60bbded160c687d", null ],
      [ "NonFaulting", "_prefetch_directive_8h.html#a36b78b48c1fe9126344a218d07348f4da744c9ae316f75de6b586a6eb11f8df0b", null ]
    ] ]
];