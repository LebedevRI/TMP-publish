var _halide_plugin_8h =
[
    [ "REGISTER_AUTOSCHEDULER", "_halide_plugin_8h.html#a93b0e5d8f635c1d0b8b5b573798d9c99", null ]
];