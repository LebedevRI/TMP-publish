var _halide_runtime_open_c_l_8h =
[
    [ "HALIDE_RUNTIME_OPENCL", "_halide_runtime_open_c_l_8h.html#a5b7ea2484a22b1b859023630d27379f3", null ],
    [ "halide_opencl_device_interface", "_halide_runtime_open_c_l_8h.html#a9758e2876354032abeecfa7ce18cc359", null ],
    [ "halide_opencl_image_device_interface", "_halide_runtime_open_c_l_8h.html#a3f492f388abbb7b05b5dcd7bcaf2c07b", null ],
    [ "halide_opencl_initialize_kernels", "_halide_runtime_open_c_l_8h.html#ae3a0e9eb87cf6dcdea1311f7000140a5", null ],
    [ "halide_opencl_run", "_halide_runtime_open_c_l_8h.html#aac24741e5f5772f21386cda0da5549e0", null ],
    [ "halide_opencl_finalize_kernels", "_halide_runtime_open_c_l_8h.html#aa594b20c8b160956fa639b7b0b2d84bb", null ],
    [ "halide_opencl_set_platform_name", "_halide_runtime_open_c_l_8h.html#aa077903adac3fb36c18f904c47fa74f9", null ],
    [ "halide_opencl_get_platform_name", "_halide_runtime_open_c_l_8h.html#a49bcf6bb5cba26ded25b7cb26cbb6aee", null ],
    [ "halide_opencl_set_device_type", "_halide_runtime_open_c_l_8h.html#aa1fda51b521497a81175e9677ad7f608", null ],
    [ "halide_opencl_get_device_type", "_halide_runtime_open_c_l_8h.html#a2fbd80b76ed348b8c8bff6099e703dac", null ],
    [ "halide_opencl_set_build_options", "_halide_runtime_open_c_l_8h.html#aa44b6a59afd0c3b17e25794db4d01986", null ],
    [ "halide_opencl_get_build_options", "_halide_runtime_open_c_l_8h.html#afa8f1064a34e17fec76d6ebf26007af0", null ],
    [ "halide_opencl_wrap_cl_mem", "_halide_runtime_open_c_l_8h.html#a3d4c505ecbcf31bbac5a33a75700b3fd", null ],
    [ "halide_opencl_image_wrap_cl_mem", "_halide_runtime_open_c_l_8h.html#a72f65e48c3395765ce4d697ac6cdf46b", null ],
    [ "halide_opencl_detach_cl_mem", "_halide_runtime_open_c_l_8h.html#a9701a524761b98f8fc80f81ff517582b", null ],
    [ "halide_opencl_get_cl_mem", "_halide_runtime_open_c_l_8h.html#a231c2547d4c5686803d06b0df063cec5", null ],
    [ "halide_opencl_get_crop_offset", "_halide_runtime_open_c_l_8h.html#a1e04490008e395a11b0c2aa344e56d1b", null ]
];