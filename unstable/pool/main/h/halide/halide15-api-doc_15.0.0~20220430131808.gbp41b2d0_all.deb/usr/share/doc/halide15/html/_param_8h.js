var _param_8h =
[
    [ "Param", "class_halide_1_1_param.html", "class_halide_1_1_param" ],
    [ "HALIDE_HANDLE_TYPE_DISPATCH", "_param_8h.html#a9f67c7a49f57f09b843f46fc354da8c1", null ],
    [ "user_context_value", "_param_8h.html#ada8877b8b863a6b16d6ff13e196ec457", null ]
];