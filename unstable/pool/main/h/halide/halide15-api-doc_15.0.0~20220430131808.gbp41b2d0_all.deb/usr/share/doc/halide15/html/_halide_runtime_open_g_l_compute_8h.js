var _halide_runtime_open_g_l_compute_8h =
[
    [ "HALIDE_RUNTIME_OPENGLCOMPUTE", "_halide_runtime_open_g_l_compute_8h.html#a4db60a99cc5bdbe4bf25df5787082007", null ],
    [ "halide_openglcompute_device_interface", "_halide_runtime_open_g_l_compute_8h.html#a6490787e5adfa2c0794f9c515164f50c", null ],
    [ "halide_openglcompute_initialize_kernels", "_halide_runtime_open_g_l_compute_8h.html#aef65ad8566680735402a2ce79c68c08b", null ],
    [ "halide_openglcompute_run", "_halide_runtime_open_g_l_compute_8h.html#aee0b83a4e501d384038c383b719fd49f", null ],
    [ "halide_openglcompute_finalize_kernels", "_halide_runtime_open_g_l_compute_8h.html#a2740f3b9e84a0c1673edc8b524fbdc06", null ],
    [ "halide_opengl_get_proc_address", "_halide_runtime_open_g_l_compute_8h.html#a9852b0cb42dd8005ac87dff543510535", null ],
    [ "halide_opengl_create_context", "_halide_runtime_open_g_l_compute_8h.html#a0b8462500d59efb7fb6010610de1726c", null ]
];