var _halide_runtime_metal_8h =
[
    [ "HALIDE_RUNTIME_METAL", "_halide_runtime_metal_8h.html#ab41b861fa7f2589cfcd8b80b1cfd712c", null ],
    [ "halide_metal_device_interface", "_halide_runtime_metal_8h.html#a62ca08763338934a10718166656f802f", null ],
    [ "halide_metal_initialize_kernels", "_halide_runtime_metal_8h.html#a4521858d8a01477b467a73fb1b8fb4c8", null ],
    [ "halide_metal_finalize_kernels", "_halide_runtime_metal_8h.html#a33c52a33b22c8c6bfa024eacbdcb4ee0", null ],
    [ "halide_metal_run", "_halide_runtime_metal_8h.html#ac5a3934d1958627ee83adb55094883b4", null ],
    [ "halide_metal_wrap_buffer", "_halide_runtime_metal_8h.html#a62ffa8b651aece537c53684bbb5d927f", null ],
    [ "halide_metal_detach_buffer", "_halide_runtime_metal_8h.html#a8e662cd7c2790e59706786ea67981591", null ],
    [ "halide_metal_get_buffer", "_halide_runtime_metal_8h.html#a760cd31440e97b819385d450ebe6904e", null ],
    [ "halide_metal_get_crop_offset", "_halide_runtime_metal_8h.html#a557cec55b481a27bb176bc5be7d500c2", null ],
    [ "halide_metal_acquire_context", "_halide_runtime_metal_8h.html#a3e8bf7e06d1d8b03f326af7c365b2e0d", null ],
    [ "halide_metal_release_context", "_halide_runtime_metal_8h.html#ae9dacd5f7750ddf41887bb209876a9f1", null ]
];