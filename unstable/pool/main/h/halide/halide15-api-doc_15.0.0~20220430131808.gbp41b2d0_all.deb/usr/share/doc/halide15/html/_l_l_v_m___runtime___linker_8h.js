var _l_l_v_m___runtime___linker_8h =
[
    [ "get_triple_for_target", "_l_l_v_m___runtime___linker_8h.html#a496ad11988df981c987a2557c3cd2d8c", null ],
    [ "get_initial_module_for_target", "_l_l_v_m___runtime___linker_8h.html#a30b2ac324e660b73262abdb4b0643451", null ],
    [ "get_initial_module_for_ptx_device", "_l_l_v_m___runtime___linker_8h.html#a9e77b70f4bfb715115d8c3a690b2faa0", null ],
    [ "add_bitcode_to_module", "_l_l_v_m___runtime___linker_8h.html#af5c2253813b438bcb811778d84b98e94", null ],
    [ "link_with_wasm_jit_runtime", "_l_l_v_m___runtime___linker_8h.html#adcb7795a6245d98b4acbda63678d436e", null ]
];