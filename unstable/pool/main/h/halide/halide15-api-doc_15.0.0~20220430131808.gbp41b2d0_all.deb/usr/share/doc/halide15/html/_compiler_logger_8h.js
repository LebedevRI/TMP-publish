var _compiler_logger_8h =
[
    [ "CompilerLogger", "class_halide_1_1_internal_1_1_compiler_logger.html", "class_halide_1_1_internal_1_1_compiler_logger" ],
    [ "JSONCompilerLogger", "class_halide_1_1_internal_1_1_j_s_o_n_compiler_logger.html", "class_halide_1_1_internal_1_1_j_s_o_n_compiler_logger" ],
    [ "set_compiler_logger", "_compiler_logger_8h.html#a735759322b0f8490b0d550f4b10f4000", null ],
    [ "get_compiler_logger", "_compiler_logger_8h.html#a58ba1f88f3490dd824db2fb31bbe6339", null ]
];