var _halide_py_torch_helpers_8h =
[
    [ "HLPT_CHECK_CONTIGUOUS", "_halide_py_torch_helpers_8h.html#a16fc1a1ae010da51439218deb7caf952", null ],
    [ "HLPT_CHECK_CUDA", "_halide_py_torch_helpers_8h.html#a0852506f5f759f5a1436fd51d72499e4", null ],
    [ "HLPT_CHECK_DEVICE", "_halide_py_torch_helpers_8h.html#a021dcf785b07c17ec7710776cc80ad36", null ],
    [ "HL_PYTORCH_API_VERSION", "_halide_py_torch_helpers_8h.html#a03aba3a5c76317f659b36f53683f677f", null ],
    [ "HL_PT_DEFINE_TYPECHECK", "_halide_py_torch_helpers_8h.html#ac7dad3a4d0d77b2c489c6fa7947b1668", null ],
    [ "halide_cuda_device_interface", "_halide_py_torch_helpers_8h.html#a320c988baf157e9f7d506d26ec4bd9e6", null ],
    [ "get_dims", "_halide_py_torch_helpers_8h.html#abc03b4d6a60c98eb04139645d0f29dc7", null ],
    [ "check_type", "_halide_py_torch_helpers_8h.html#ae53aca5d30ab4e127f7f09294bdf1cbe", null ],
    [ "AT_FORALL_SCALAR_TYPES_WITH_COMPLEX", "_halide_py_torch_helpers_8h.html#ab44292622ebe073cd40bf9e8f3050789", null ],
    [ "wrap", "_halide_py_torch_helpers_8h.html#a4c6738ebbb0086ea6b4bbd33eef254bd", null ],
    [ "wrap_cuda", "_halide_py_torch_helpers_8h.html#a8b01ba5d3a1e8c7f949cb6f2957789df", null ]
];