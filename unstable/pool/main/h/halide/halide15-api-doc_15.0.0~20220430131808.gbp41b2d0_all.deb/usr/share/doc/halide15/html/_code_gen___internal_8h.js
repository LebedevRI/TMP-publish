var _code_gen___internal_8h =
[
    [ "llvm_type_of", "_code_gen___internal_8h.html#a71f10140e29131153c3be98d2899b090", null ],
    [ "get_vector_num_elements", "_code_gen___internal_8h.html#ad99e3563cd430c42905e547bfb02082b", null ],
    [ "get_vector_element_type", "_code_gen___internal_8h.html#a1df32a68c28abfa75e1a5e397817a674", null ],
    [ "element_count", "_code_gen___internal_8h.html#a734d73b10891945e13b9dfdedc4d7f85", null ],
    [ "get_vector_type", "_code_gen___internal_8h.html#a28e666b9660ff646f788264bf2f08b95", null ],
    [ "function_takes_user_context", "_code_gen___internal_8h.html#adc60421b682a09ea4c4dcaaaa3e105e2", null ],
    [ "can_allocation_fit_on_stack", "_code_gen___internal_8h.html#a4abe6b887804e86f403f0af16d5a2ba1", null ],
    [ "long_div_mod_round_to_zero", "_code_gen___internal_8h.html#a14294d4d56333f9579e1cb083347df30", null ],
    [ "lower_int_uint_div", "_code_gen___internal_8h.html#a25b077cb4a97dbf2fc64bb665826b512", null ],
    [ "lower_int_uint_mod", "_code_gen___internal_8h.html#a3b44815561924377a690cf1d967bd19f", null ],
    [ "lower_euclidean_div", "_code_gen___internal_8h.html#ab7a4f18b650b23e1e6ed980d1feebcf5", null ],
    [ "lower_euclidean_mod", "_code_gen___internal_8h.html#ae81d78fd7f3115750e17167ebf0fe920", null ],
    [ "lower_signed_shift_left", "_code_gen___internal_8h.html#a9ce06cce9e67778758fd7090bd991421", null ],
    [ "lower_signed_shift_right", "_code_gen___internal_8h.html#a2637f42ac63c862b5f2a279164d640d1", null ],
    [ "lower_mux", "_code_gen___internal_8h.html#a7a110889396502096d2b5e3995734ef6", null ],
    [ "get_target_options", "_code_gen___internal_8h.html#a7b4fa94b1f3a877eb3387824c09df826", null ],
    [ "clone_target_options", "_code_gen___internal_8h.html#a1b16d175882e16f544bf4bf92ec931b5", null ],
    [ "make_target_machine", "_code_gen___internal_8h.html#af1e20aff45028d266f854487159df341", null ],
    [ "set_function_attributes_for_target", "_code_gen___internal_8h.html#a01e7008bc30f56a6cbfb69a120ccf0d0", null ],
    [ "embed_bitcode", "_code_gen___internal_8h.html#a36fd598253847fcd510e32b107aeb2f3", null ]
];