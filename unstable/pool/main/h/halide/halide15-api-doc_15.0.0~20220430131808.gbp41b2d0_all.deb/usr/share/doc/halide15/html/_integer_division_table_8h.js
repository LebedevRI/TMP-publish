var _integer_division_table_8h =
[
    [ "table_u8", "_integer_division_table_8h.html#a99facb3ec68a1eadbb143071dc4c9046", null ],
    [ "table_s8", "_integer_division_table_8h.html#a9206d6b163b3efa3c6f3c51608f7f5dd", null ],
    [ "table_srz8", "_integer_division_table_8h.html#adc008095f0afc51b3c78cc7e92137153", null ],
    [ "table_u16", "_integer_division_table_8h.html#a96410a3bd0b344ef4e4b1df41d58b988", null ],
    [ "table_s16", "_integer_division_table_8h.html#ac5f9bc0b8567ddc4db38c5eb35b781d7", null ],
    [ "table_srz16", "_integer_division_table_8h.html#a7049099132c9a90040ed5055d2462542", null ],
    [ "table_u32", "_integer_division_table_8h.html#ab70f2f1436ac0dd8e4a68f8bc215ec3f", null ],
    [ "table_s32", "_integer_division_table_8h.html#ac50a694f153b4c334a30fcb11896f507", null ],
    [ "table_srz32", "_integer_division_table_8h.html#a5a7892997dfdc1ac816f70e56681e6cb", null ],
    [ "table_runtime_u8", "_integer_division_table_8h.html#a6a8eb9eab933d564f752b966ec1230bb", null ],
    [ "table_runtime_s8", "_integer_division_table_8h.html#a8156746a3925ef97a89198aaa98d1947", null ],
    [ "table_runtime_srz8", "_integer_division_table_8h.html#a6b899054deabb62a23c07d48e09c406b", null ],
    [ "table_runtime_u16", "_integer_division_table_8h.html#a7cc9ac800bb1b69da0aaca8e8e683f37", null ],
    [ "table_runtime_s16", "_integer_division_table_8h.html#ad3e76e6447c170caf7c7a345fb55b91c", null ],
    [ "table_runtime_srz16", "_integer_division_table_8h.html#a165f48bdc57017ce7f9ea730b3213f3e", null ],
    [ "table_runtime_u32", "_integer_division_table_8h.html#a3da9cf42a5c44f74534efc749a277984", null ],
    [ "table_runtime_s32", "_integer_division_table_8h.html#aa6ee31c22aff7ca2fe03668bd73429d1", null ],
    [ "table_runtime_srz32", "_integer_division_table_8h.html#a00d36aea7f649b5a613553c4e3c07d47", null ]
];