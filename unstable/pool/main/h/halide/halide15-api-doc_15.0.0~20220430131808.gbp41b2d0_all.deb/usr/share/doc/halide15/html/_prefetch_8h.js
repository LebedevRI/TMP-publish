var _prefetch_8h =
[
    [ "inject_placeholder_prefetch", "_prefetch_8h.html#a9d9e0c79704de005e7e9ca2283da97c6", null ],
    [ "inject_prefetch", "_prefetch_8h.html#ab1427ae551e1c2cce79b7042c3fa4620", null ],
    [ "reduce_prefetch_dimension", "_prefetch_8h.html#a23cbede92a4cd09354b032a40829a9d1", null ],
    [ "hoist_prefetches", "_prefetch_8h.html#ae4cb2c3d2c016e1eb6e6621599f9d731", null ]
];