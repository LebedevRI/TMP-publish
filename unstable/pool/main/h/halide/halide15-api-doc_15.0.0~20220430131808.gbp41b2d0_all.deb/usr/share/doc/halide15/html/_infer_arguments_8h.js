var _infer_arguments_8h =
[
    [ "InferredArgument", "struct_halide_1_1_internal_1_1_inferred_argument.html", "struct_halide_1_1_internal_1_1_inferred_argument" ],
    [ "infer_arguments", "_infer_arguments_8h.html#af522a6ad40733cb252fc7547a8af7dce", null ]
];