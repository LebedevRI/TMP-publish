var _halide_runtime_d3_d12_compute_8h =
[
    [ "halide_d3d12compute_device_interface", "_halide_runtime_d3_d12_compute_8h.html#ae3428b555c0a0a7ff2fa92a6e2be6cb7", null ],
    [ "halide_d3d12compute_initialize_kernels", "_halide_runtime_d3_d12_compute_8h.html#a96e72f1e76c8c53e363f4d409324e6aa", null ],
    [ "halide_d3d12compute_run", "_halide_runtime_d3_d12_compute_8h.html#a3c2c1591f2aa4584effced74a471d92b", null ],
    [ "halide_d3d12compute_finalize_kernels", "_halide_runtime_d3_d12_compute_8h.html#a83bdc42873d8bf0dafa4a54329cd34c0", null ],
    [ "halide_d3d12compute_wrap_buffer", "_halide_runtime_d3_d12_compute_8h.html#a88313600779c1d6daa4a05a16ed3b976", null ],
    [ "halide_d3d12compute_detach_buffer", "_halide_runtime_d3_d12_compute_8h.html#a76d6dfc3562479e3edf52fbf86db8abc", null ],
    [ "halide_d3d12compute_get_buffer", "_halide_runtime_d3_d12_compute_8h.html#a6f3cb7ed0d2b23678314833764ecfb4e", null ],
    [ "halide_d3d12compute_acquire_context", "_halide_runtime_d3_d12_compute_8h.html#a217d1cc85472e27de2f7a03e0f37cd36", null ],
    [ "halide_d3d12compute_release_context", "_halide_runtime_d3_d12_compute_8h.html#ac46c55d99425054b35999f60815a0624", null ]
];