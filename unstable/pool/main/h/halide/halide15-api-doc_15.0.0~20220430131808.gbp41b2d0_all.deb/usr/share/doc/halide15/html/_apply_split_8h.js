var _apply_split_8h =
[
    [ "ApplySplitResult", "struct_halide_1_1_internal_1_1_apply_split_result.html", "struct_halide_1_1_internal_1_1_apply_split_result" ],
    [ "apply_split", "_apply_split_8h.html#aab98c44d7a462e3217c6a4f6ddbe3bc7", null ],
    [ "compute_loop_bounds_after_split", "_apply_split_8h.html#a639111963bc0698b1b724299ec35b840", null ]
];