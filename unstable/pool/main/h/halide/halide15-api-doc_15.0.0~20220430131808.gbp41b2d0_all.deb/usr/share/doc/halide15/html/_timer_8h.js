var _timer_8h =
[
    [ "ScopedTimer", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_scoped_timer.html", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_scoped_timer" ],
    [ "Timer", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_timer.html", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_timer" ],
    [ "Clock", "_timer_8h.html#ad3163bddcbad52ba9b807cffb6f6ab29", null ]
];