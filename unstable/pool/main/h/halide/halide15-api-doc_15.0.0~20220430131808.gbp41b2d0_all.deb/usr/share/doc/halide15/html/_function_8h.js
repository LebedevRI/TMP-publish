var _function_8h =
[
    [ "Function", "class_halide_1_1_internal_1_1_function.html", "class_halide_1_1_internal_1_1_function" ],
    [ "Compare", "struct_halide_1_1_internal_1_1_function_1_1_compare.html", "struct_halide_1_1_internal_1_1_function_1_1_compare" ],
    [ "NameMangling", "_function_8h.html#a9a0a73a2b8a7322d8ac330adfce8d134", [
      [ "Default", "_function_8h.html#a9a0a73a2b8a7322d8ac330adfce8d134a7a1920d61156abc05a60135aefe8bc67", null ],
      [ "C", "_function_8h.html#a9a0a73a2b8a7322d8ac330adfce8d134a0d61f8370cad1d412f80b84d143e1257", null ],
      [ "CPlusPlus", "_function_8h.html#a9a0a73a2b8a7322d8ac330adfce8d134a618c337d168d3e2f339a16f8f6069c20", null ]
    ] ],
    [ "deep_copy", "_function_8h.html#aad946e0645ead551baee06d6c39e6552", null ]
];