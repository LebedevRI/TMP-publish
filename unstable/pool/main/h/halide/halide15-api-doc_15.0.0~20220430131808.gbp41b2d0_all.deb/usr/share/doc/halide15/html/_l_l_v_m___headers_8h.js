var _l_l_v_m___headers_8h =
[
    [ "iterator_to_pointer", "_l_l_v_m___headers_8h.html#a6e9d2c57ff18ef709b6a4e444f4af5ff", null ],
    [ "get_llvm_function_name", "_l_l_v_m___headers_8h.html#a880810f84064e696c65e574223e8170a", null ],
    [ "get_llvm_function_name", "_l_l_v_m___headers_8h.html#ae2e2fec06de5b48f541b7a7b18d7bfb1", null ],
    [ "get_llvm_struct_type_by_name", "_l_l_v_m___headers_8h.html#ab26aedcbbf9449fa19edd76ad289ff26", null ]
];