var _monotonic_8h =
[
    [ "Monotonic", "_monotonic_8h.html#a7dc0c8c1adc38d2c5a80979948f0007c", [
      [ "Constant", "_monotonic_8h.html#a7dc0c8c1adc38d2c5a80979948f0007cacb17869fe51048b5a5c4c6106551a255", null ],
      [ "Increasing", "_monotonic_8h.html#a7dc0c8c1adc38d2c5a80979948f0007caf3ff61f20d0c8eedfa348b0298df5edd", null ],
      [ "Decreasing", "_monotonic_8h.html#a7dc0c8c1adc38d2c5a80979948f0007ca2e6a9b0375c021e8f650a5eb22012b5b", null ],
      [ "Unknown", "_monotonic_8h.html#a7dc0c8c1adc38d2c5a80979948f0007ca88183b946cc5f0e8c96b2e66e1c74a7e", null ]
    ] ],
    [ "derivative_bounds", "_monotonic_8h.html#a0301c6ab3540d1ce4c678d7f625d23b0", null ],
    [ "is_monotonic", "_monotonic_8h.html#a51a4b2947237a60faeb58784f49818c7", null ],
    [ "is_monotonic", "_monotonic_8h.html#a86052cc97eb7a7774977da430b03274b", null ],
    [ "operator<<", "_monotonic_8h.html#a283407774a5c9a29ab30e9223dcb3580", null ],
    [ "is_monotonic_test", "_monotonic_8h.html#af6de4b237eafb498206aa2eb0c94b4ad", null ]
];